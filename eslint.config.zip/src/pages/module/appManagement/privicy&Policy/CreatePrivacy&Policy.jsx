import React, { useRef, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Formik, Form, ErrorMessage } from "formik";
import * as Yup from "yup";
import JoditEditor from "jodit-pro-react";
import BreadCrumb from "../../../../components/uiComponent/BreadCrumb";
import PagePath2 from "../../../../components/uiComponent/PagePath2";
import Button from "../../../../components/uiComponent/Button";
import FormField from "../../../../components/uiComponent/FormField";
import usePrivacyPolicy from "../../../../hooks/appManagement/usePrivacyAndPolicy";
import LoaderSpinner from "../../../../components/uiComponent/LoaderSpinner";
import useDropdown from "../../../../hooks/dropdown/useDropdown";

function CreatePrivacyPolicy() {
  const navigate = useNavigate();
  const { id } = useParams();
  const editor = useRef(null);

  const {
    loading: privacyLoading,
    privacyPolicyDetail,
    createPrivacyPolicy,
    updatePrivacyPolicy,
    fetchPrivacyPolicyById,
    resetPrivacyPolicyDetails,
  } = usePrivacyPolicy();

  // Use dropdown hook for user types
  const {
    userType,
    loadingUser,
    fetchUserType,
  } = useDropdown();

  // Fetch privacy policy details if editing
  useEffect(() => {
    if (id) {
      fetchPrivacyPolicyById(id);
    }

    return () => {
      resetPrivacyPolicyDetails();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  // Fetch user types on mount
  useEffect(() => {
    fetchUserType();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Convert userType from dropdown hook to options format
 
    const roleOptions = Array.isArray(userType)
  ? userType.map((item) => {
      if (typeof item === "string") {
        return { label: item, value: item };
      }

      return {
        label: item.name,
        value: item.name,
      };
    })
  : [];


  // Validation schema
  const validationSchema = Yup.object({
    role: Yup.string().required("Role is required"),
    content: Yup.string()
      .required("Privacy Policy content is required")
      .test("not-empty", "Privacy Policy content is required", (value) => {
        // Remove HTML tags and check if content is empty
        const strippedContent = value?.replace(/<[^>]*>/g, "").trim();
        return strippedContent && strippedContent.length > 0;
      }),
  });

  const handleSubmit = async (values) => {
    const formData = {
      role: values.role,
      content: values.content,
      requestType: id ? "Update" : "Create",
      id: id ? id : null,
    };

    let result;
    if (id) {
      result = await updatePrivacyPolicy(id, formData);
    } else {
      result = await createPrivacyPolicy(formData);
    }

    // Navigate after successful operation
    if (result) {
      navigate("/app-management/privacy-policy");
    }
  };

  // Jodit editor configuration
  const config = {
    readonly: false,
    placeholder: "Start typing your privacy policy content...",
    minHeight: 400,
    buttons: [
      "bold",
      "italic",
      "underline",
      "|",
      "ul",
      "ol",
      "|",
      "font",
      "fontsize",
      "brush",
      "|",
      "align",
      "undo",
      "redo",
      "|",
      "link",
      "table",
      "|",
      "hr",
      "symbol",
      "fullsize",
    ],
    removeButtons: ["file", "video", "ai-assistant"],
    showCharsCounter: false,
    showWordsCounter: false,
    showXPathInStatusbar: false,
    toolbarAdaptive: false,
  };

  // Show loading state while fetching data for edit mode
  if (id && privacyLoading && !privacyPolicyDetail) {
    return (
      <div className="bg-[#F9F9F9] min-h-screen">
        <BreadCrumb
          linkText={[
            { text: "App Management" },
            { text: "Privacy Policy", href: "/app-management/privacy-policy" },
            { text: "Edit Privacy Policy" },
          ]}
        />
        <PagePath2 title="Edit Privacy Policy" />
        <div className="bg-white border border-gray-200 shadow-xl rounded-2xl p-6 mt-4">
          <div className="flex justify-center items-center py-20">
            <LoaderSpinner />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#F9F9F9] min-h-screen">
      {/* Breadcrumb Section */}
      {id ? (
        <BreadCrumb
          linkText={[
            { text: "App Management" },
            { text: "Privacy Policy", href: "/app-management/privacy-policy" },
            { text: "View Details", href: `/app-management/privacy-policy/view/${id}` },
            { text: "Edit Privacy Policy" },
          ]}
        />
      ) : (
        <BreadCrumb
          linkText={[
            { text: "App Management" },
            { text: "Privacy Policy", href: "/app-management/privacy-policy" },
            { text: "Create Privacy Policy" },
          ]}
        />
      )}

      {/* Page Header */}
      <PagePath2 title={id ? "Edit Privacy Policy" : "Create Privacy Policy"} />

      {/* Form Card */}
      <div className="bg-white border border-gray-200 shadow-xl rounded-2xl p-6 mt-4">
        <Formik
          initialValues={{
            role: privacyPolicyDetail?.role || "",
            content: privacyPolicyDetail?.content || "",
          }}
          validationSchema={validationSchema}
          enableReinitialize
          onSubmit={handleSubmit}
        >
          {({ values, setFieldValue, isSubmitting, errors, touched }) => (
            <Form className="flex flex-col gap-6">
              {/* Role Dropdown */}
              <div className="grid grid-cols-1 md:grid-cols-2 w-full gap-6">
                <FormField
                  label="Select Role"
                  name="role"
                  fieldType="select"
                  options={roleOptions}
                  placeholder="Select Role"
                  loading={loadingUser}
                  disabled={loadingUser}
                  required
                />
              </div>

              {/* Privacy Policy Editor */}
              <div className="flex flex-col gap-3">
                <label className="text-sm font-medium text-gray-700">
                  Privacy Policy Content <span className="text-red-500">*</span>
                </label>
                <div
                  className={`border rounded-lg overflow-hidden ${
                    errors.content && touched.content
                      ? "border-red-500"
                      : "border-gray-300"
                  }`}
                >
                  <JoditEditor
                    ref={editor}
                    value={values.content}
                    config={config}
                    tabIndex={1}
                    onBlur={(newContent) => setFieldValue("content", newContent)}
                    onChange={() => {}}
                  />
                </div>
                <ErrorMessage
                  name="content"
                  component="div"
                  className="text-red-500 text-sm mt-1"
                />
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-center mt-6 gap-6">
                <Button
                  variant={2}
                  text="Cancel"
                  onClick={() => navigate("/app-management/privacy-policy")}
                  disabled={privacyLoading || isSubmitting}
                />
                <Button
                  variant={1}
                  text={
                    privacyLoading || isSubmitting
                      ? id
                        ? "Updating..."
                        : "Creating..."
                      : id
                      ? "Update"
                      : "Create"
                  }
                  type="submit"
                  disabled={privacyLoading || isSubmitting}
                />
              </div>
            </Form>
          )}
        </Formik>
      </div>
    </div>
  );
}

export default CreatePrivacyPolicy;